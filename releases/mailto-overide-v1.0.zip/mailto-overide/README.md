# mailto:overide

This project is to create a chrome extension that will over-ride the html `mailto:` syntax from opening and email client, to comply copying the email address to your clipboard. 